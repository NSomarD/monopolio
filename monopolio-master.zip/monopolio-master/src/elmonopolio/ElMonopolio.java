package elmonopolio;
// import clases.*;

/**
 *
 * @author Omar
 */
public class ElMonopolio {

    public static void main(String[] args) {
        
    }
    
}
