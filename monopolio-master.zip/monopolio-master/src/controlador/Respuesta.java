package controlador;

public enum Respuesta {
    NO,
    SI;
}
