package clases;

public enum OperacionInmobiliaria {
    CONSTRUIR_CASA,
    CONSTRUIR_HOTEL,
    TERMINAR;
}
