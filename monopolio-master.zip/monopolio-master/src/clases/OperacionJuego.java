package clases;

public enum OperacionJuego {
    PASAR_TURNO,
    AVANZAR,
    COMPRAR,
    GESTIONAR;
}
