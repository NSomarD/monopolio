package clases;

public enum TipoSorpresa {
    PAGARCOBRAR,
    PORCASAHOTEL;
}
