package clases;

public enum TipoCasilla {
    CALLE,
    DESCANSO,
    SORPRESA;
}
